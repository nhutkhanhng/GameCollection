﻿using UnityEngine;

namespace Zenject.Tests.Bindings.FromGameObjectInstaller
{
    public interface IFoo
    {
    }

    public class Foo : MonoBehaviour, IFoo
    {
    }
}
