using UnityEngine;

namespace Zenject.Tests.Bindings.FromPrefabResource
{
    public class Norf2 : MonoBehaviour, INorf
    {
    }
}

