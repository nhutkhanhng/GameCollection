using UnityEngine;

namespace Zenject.Tests.Bindings.FromComponentInHierarchyGameObjectContext
{
    public class Gorp : MonoBehaviour
    {
    }
}

