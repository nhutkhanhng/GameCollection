namespace Zenject.Asteroids
{
    public class ShipCrashedSignal
    {
    }
}
