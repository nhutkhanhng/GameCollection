using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnEffect : MonoBehaviour{
    public Animator FallEffect;
    public Animator JumpEffect;

    public void ShowEffect(string name){
        switch (name){
            case "Fall":
                FallEffect.gameObject.SetActive(true);
                FallEffect.Play("fall");
                break;
            case "Jump":
                JumpEffect.gameObject.SetActive(true);
                JumpEffect.Play("jump");
                break;
        }
    }

    private void HideEffect(){
        
    }
}
