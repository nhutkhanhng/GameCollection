using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HideGameObject : MonoBehaviour
{
   public void HideObject(){
      gameObject.SetActive(false);
   }
}
