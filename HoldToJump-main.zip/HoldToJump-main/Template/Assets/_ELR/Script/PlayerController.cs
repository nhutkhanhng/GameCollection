using System;
using System.Collections;
using System.Collections.Generic;
using System.Numerics;
using UnityEngine;
using Vector2 = UnityEngine.Vector2;

public class PlayerController : MonoBehaviour
{
    //public Animator PlayerAnimator
    // public delegate void DoAnim(string name);
    //
    // public event DoAnim PlayAnimation;

    public Animator PlayerAnimator;

    public int JumpForce;
    public bool IsGrounded;
    public Vector2 Velocity;
    public float maxXVelocity = 100;
    public float acceleration = 10;
    public float maxAcceleration = 10;
    public Rigidbody2D Rigid2d;
    private bool _canDoubleJump;
    private void Awake(){
        Rigid2d = gameObject.GetComponent<Rigidbody2D>();
    }
    private void Start(){
    }
    private void Update() {
        if (Input.GetMouseButtonDown(0)){
            if (IsGrounded){
                Jump();
                _canDoubleJump = true;
                IsGrounded = false;
                return;
            }
            if (_canDoubleJump){
                Jump(true);
                _canDoubleJump = false;
            }
        }
    }

    private void FixedUpdate(){
        UpdatePlayerPos();
    }

    private void OnCollisionEnter2D(Collision2D collision){
        if (collision.gameObject.CompareTag("Ground")){
            if (!IsGrounded){
                IsGrounded = true;
                PlayerAnimator.Play("run");
                Debug.Log(IsGrounded);
            }
        }
    }

    private void Jump(bool doubleJump = false){
        
        Rigid2d.AddForce(Vector2.up * JumpForce);
        if (doubleJump){
            PlayerAnimator.Play("double_jump");
            _canDoubleJump = false;
            return;
        }
        PlayerAnimator.Play("jump");
    }

    private void UpdatePlayerPos(){
        Vector2 pos = transform.position;
        if (IsGrounded){
            float velocityRatio = Velocity.x / maxXVelocity;
            acceleration = maxAcceleration * (1 - velocityRatio);
            Velocity.x += acceleration * Time.fixedDeltaTime;
            if (Velocity.x >= maxXVelocity)
            {
                Velocity.x = maxXVelocity;
            }
        }

        transform.position = pos;
    }
}
