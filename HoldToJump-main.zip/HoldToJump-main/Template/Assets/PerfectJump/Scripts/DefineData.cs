using System.Collections;
using System.Collections.Generic;
using UnityEngine;



public class DefineData
{
    public class Tag
    {
        public const string Player = "Player";
        public const string Obstacle = "Obstacle";
        
    }


    public class LayerTag
    {
        // 
    }
    
}