using System.Collections;
using System.Collections.Generic;
using UnityEngine;


[CreateAssetMenu(fileName = "ComplexData", menuName = "Complex/Config", order = 1)]
public class ComplexData : ScriptableObject
{
    public Obstacle defaultObstacle;
    [System.Serializable]
    public struct Config
    {
        [MinMaxCustomSlider]
        public ValueRange xDistanceBetweenObstacles;
        public List<Obstacle> obstacles;

        public Obstacle GetRandom()
        {
            return obstacles[UnityEngine.Random.Range(0, obstacles.Count)];
        }

        public float GetDistance() => xDistanceBetweenObstacles.GetRandomValue();
    }


    public int[] reachPoints;
    public Config[] ComplexRelyOnLevel;

    public Config this[int i] => ComplexRelyOnLevel[Mathf.Clamp(i, 0, ComplexRelyOnLevel.Length -1)];
}
