﻿using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
[RequireComponent(typeof(TrailRenderer))]
[RequireComponent(typeof(SpriteRenderer))]
public class Player : MonoBehaviour
{
    public Rigidbody2D rigid;
    public TrailRenderer trail;
    public SpriteRenderer spriteRenderer;
    public Material trailMaterial;
    public Animator PlayerAnimator;


    public System.Action<Player> OnJump;
    private void OnBecameInvisible()
    {
        if (Camera.main && Camera.main.WorldToScreenPoint(transform.position).y > Screen.height)
        {
            return;
        }

        // falling
        rigid.bodyType = RigidbodyType2D.Static;
        spriteRenderer.enabled = false;
        //trail.enabled = false;
    
        if (GameManager.Instance.uIManager.gameState == GameState.PLAYING)
            GameManager.Instance.GameOver();
    }

    public GameObject before = null;

    public void ResetValue()
    {
        before = null;
    }

    protected Vector3 oldPosition;
    //when player hit obstacle object
    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag(DefineData.Tag.Obstacle))
        {
            Rigidbody2D tempRigidbody2D = collision.gameObject.GetComponent<Rigidbody2D>();
            Obstacle obs = collision.gameObject.GetComponent<Obstacle>();
            if (!obs)
                return;
            
            //dont play hit sound on first obstacle
            if (obs.index == 0)
            {
                before = obs.gameObject;
                oldPosition = obs.transform.position;
                trailMaterial.color = collision.gameObject.GetComponent<SpriteRenderer>().color;
                PlayerAnimator.Play("idle");
                GameManager.Instance.inAir = false;
                //spriteRenderer.color = collision.gameObject.GetComponent<SpriteRenderer>().color;
                return;
            }

            Sound.PlayHit(); 

            //Debug.Log(Mathf.Abs(collision.transform.position.x - transform.position.x));
            
            // if (Mathf.Abs(collision.transform.position.x - transform.position.x) > .45f) //more than half player si over the obstacle so dont enable gravity for it
            // {
            //     GameManager.Instance.GameOver();
            //     rigid.angularVelocity = 0;
            //     rigid.velocity = Vector2.zero;
            // }
            // else
            {
                // i dont know why ? but if u use collision equals result always true.
                // I think because Instantiate from the same prefab template.
                if (collision.gameObject.Equals(before))
                {
                    // GameManager.Instance.GameOver();
                }
                else
                {
                    //perfect hit
                    if (Mathf.Abs(collision.transform.position.x - transform.position.x) < .15f)
                    {
                        Sound.PlayPerfect();
                        // force position
                        transform.position = new Vector2(collision.transform.position.x, transform.position.y);
                        GameManager.Instance.UpdateScore(2);
                        GameManager.Instance.PlayPerfect();
                    }
                    else
                    {
                        GameManager.Instance.UpdateScore(1);
                    }

                    before = collision.gameObject;
                    oldPosition = obs.transform.position;
                }

                transform.rotation = new Quaternion(0, 0, 0, 0);
                // rigid.angularVelocity = 0;
                // rigid.velocity = Vector2.zero;
                GameManager.Instance.inAir = false;
                PlayerAnimator.Play("idle");
               
                // tempRigidbody2D.bodyType = RigidbodyType2D.Dynamic;
                // tempRigidbody2D.gravityScale = 3f;
                // tempRigidbody2D.constraints = RigidbodyConstraints2D.FreezePositionX | RigidbodyConstraints2D.FreezeRotation;

                GameManager.Instance.PlayerGroundedHit(this, obs);
                
                // PlayerAnimator.transform.GetComponent<SpriteRenderer>().material.color = spriteRenderer.color = _spriteRenderer.color;
                 // PlayerAnimator.transform.GetComponent<SpriteRenderer>().material.color = collision.gameObject.GetComponent<SpriteRenderer>().color;
                // trailMaterial.color = spriteRenderer.color = _spriteRenderer.color;
                // trailMaterial.color = collision.gameObject.GetComponent<SpriteRenderer>().color;
            }
        }
    }

}
