using System;
using System.Collections;
using System.Collections.Generic;
using Unity.Collections;
using UnityEngine;
using Object = UnityEngine.Object;
using Random = UnityEngine.Random;


public class ComplexRule
{
    public GameManager gameManager;
    public ComplexSystem complexSystem;

    public ComplexRule(GameManager manager, ComplexSystem system)
    {
        this.gameManager = manager;
        this.complexSystem = system;
    }
    public Obstacle lastObstacle => complexSystem.lastObstacle;
    public Obstacle newObstacle => complexSystem.newObstacle;
    
    public ref Vector3 screenSize => ref gameManager.screenSize;
    public Camera cam => gameManager.cam;
    
    public virtual bool ConditionCreate()
    {
        return (lastObstacle.transform.position.x < cam.transform.position.x + screenSize.x * .75f);
    }
}

[System.Serializable]
public sealed class ComplexSystem
{
    public GameManager gameManager;
    public Obstacle lastObstacle;
    public Obstacle newObstacle;


    [SerializeField] public ComplexData data;
    public ComplexRule rule;
    [SerializeField] protected int _currentLevel = 0;
    public int CurrentLevel => _currentLevel;

    public void Init(GameManager manager)
    {
        this.gameManager = manager;
        rule = new ComplexRule(manager, this);
        _currentLevel = 0;
    }

    public void UpdateLevel(int score)
    {
        var configs = data.reachPoints;
        
        for (int i = configs.Length - 1; i >= 0; i--)
        {
            if (configs[i] <= score)
            {
                _currentLevel = i;
                return;
            }
        }
    }
    public void DoUpdate(float deltaTime)
    {
        if (rule.ConditionCreate())
        {
            lastObstacle = GetNewObstacle();
        }
    }

    public void CreateNewObstacle()
    {
        lastObstacle = GetNewObstacle();
        
    }
    Obstacle GetNewObstacle()
    {
        gameManager.obstacleIndex++;
        
        //random y position, depend on previous obstacle
        float newObstacleY = Random.Range(lastObstacle.transform.position.y - 1.25f, lastObstacle.transform.position.y + 1.25f);

        //dont go over the top limit
        if (newObstacleY > gameManager.maxYObstaclePosition)
            newObstacleY = gameManager.maxYObstaclePosition;

        //dont go bellow the bottom limit
        if (newObstacleY < gameManager.minYObstaclePosition)
            newObstacleY = gameManager.minYObstaclePosition;
        
        float x = lastObstacle.transform.position.x + lastObstacle.Size.x * 1.15f 
                                                    +
                                                    data[_currentLevel].GetDistance();

        newObstacle = Object.Instantiate(data[_currentLevel].GetRandom());
        var newPosition = new Vector2(x, newObstacleY);
        // Debug.LogError(Camera.main.WorldToScreenPoint(newPosition).x);
        // if (Screen.width> Camera.main.WorldToScreenPoint(newPosition).x)
        // {
        //     Debug.LogError("EEEE");
        //     float y = newPosition.y;
        //     newPosition = Camera.main.ScreenToWorldPoint(new Vector2(Screen.width, Screen.height / 2));
        //     newPosition.y = y;
        // }

        newObstacle.transform.position = newPosition;
        newObstacle.spriteRenderer.color = gameManager.GetRandomColor();
        newObstacle.index = gameManager.obstacleIndex;
        newObstacle.Init();
        
        return newObstacle;
    }

    public Camera cam => gameManager.cam;
    public Player player => gameManager.player;

    public float xDistanceBetweenObstacles => gameManager.xDistanceBetweenObstacles; 
    public ref int obstacleIndex => ref gameManager.obstacleIndex;

    public void CreateScene()
    {
        gameManager.obstacleIndex = 0;
        //reset camera position
        cam.transform.position = new Vector3(0, 0, -10);

        //first obstacle
        lastObstacle = Object.Instantiate(data.defaultObstacle);
        lastObstacle.transform.position = new Vector2(-1.5f, -2f);
        lastObstacle.spriteRenderer.color = gameManager.GetRandomColor();
        lastObstacle.GetComponent<Obstacle>().index = obstacleIndex;
        lastObstacle.Init();

        //player on the first obstacle
        player.ResetValue();
        player.transform.position = new Vector2(-1.5f, -1.3f);
        player.transform.rotation = new Quaternion(0,0,0,0);
        player.rigid.bodyType = RigidbodyType2D.Dynamic;
        player.spriteRenderer.enabled = true;
        player.trail.enabled = true;
        player.rigid.gravityScale = 3f;

        obstacleIndex++;

        //second obstacle
        lastObstacle = GetNewObstacle();
        lastObstacle.transform.position = new Vector2(1f, -1f);
        lastObstacle.spriteRenderer.color = gameManager.GetRandomColor();
        lastObstacle.GetComponent<Obstacle>().index = obstacleIndex;
    }
}
