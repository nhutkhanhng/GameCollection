﻿using System;
using UnityEngine;
using UnityEngine.UI;
using Random = UnityEngine.Random;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance { get; set; }

    public UIManager uIManager;
    public ScoreManager scoreManager;
    public Player player;
    public Rigidbody2D playerRigidbody2D;
    public GameObject obstaclePrefab;
    public Camera cam;
    public Animator perfectAnimator;
    public Animator PlayerAnimator;
    public Animator FallEffect;
    public Animator JumpEffect;
    [Header("Game settings")]
    [Space(5)]
    public float minYObstaclePosition = -4f;
    [Space(5)]
    public float maxYObstaclePosition = 2f;
    [Space(5)]
    public Color[] obstacleColors;

    public float xDistanceBetweenObstacles = 2.5f; //fixed because of first jump, if you change this then you need to change jump force too
    GameObject lastObstacle;
    GameObject newObstacle;
    public Vector3 screenSize;
    public int obstacleIndex;

    public bool inAir;

    public Slider energyHold;

    void Awake()
    {
        DontDestroyOnLoad(this);

        if (Instance == null)
            Instance = this;
        else
            Destroy(gameObject);
    }

    public float xDirectionForce = 95;

    public float yDirectionForce = 440f;

    // Start is called before the first frame update
    void Start()
    {
        screenSize = Camera.main.ScreenToWorldPoint(new Vector3(Screen.width, Screen.height, 0));
        //Debug.Log(screenSize);

        Physics2D.gravity = new Vector2(0, -9.81f);
        Application.targetFrameRate = 60;
        CreateScene();
    }

    protected float _StartHoldTime;
    protected float holdTime = 0f;
    public float yPerTick = 80f;
    public float Tick = .5f;

    public float MinForce = 0;
    [Range(110, 800)] public float MaxForce = 440;

    protected bool IsHolding = false;

    public bool IsAutoJump = true;

    public void AutoJump()
    {
        if (inAir == false && IsAutoJump)
        {
            float xD = Mathf.Abs(player.transform.position.x - findNearestObstacle().transform.position.x);
            
            // playerRigidbody2D.AddForce(new Vector2(95, xD * 155f));
            PlayerJump(yCalculated: xD* 155f);
        }
    }

    protected void PlayerJump(float yCalculated)
    {
        player.OnJump?.Invoke(player);
        
        playerRigidbody2D.velocity = Vector2.zero;
        playerRigidbody2D.AddForce(new Vector2(95, yCalculated));
        inAir = true;
        PlayerAnimator.Play("jump");
        PlayAnim("jump", GetRandomColor());
        
#if UNITY_EDITOR
        Debug.Log("<color=blue> Jump </color>");
#endif
        
    }

    public void PlayerGroundedHit(Player player, Obstacle obstacle)
    {
        SpriteRenderer _spriteRenderer = obstacle.GetComponent<SpriteRenderer>();
        //player.trail.sharedMaterial.color = _spriteRenderer.color;
        GameManager.Instance.PlayAnim("fall",_spriteRenderer.color);
        obstacle.BeHitted(player);
        
        // for auto jump
        GameManager.Instance.AutoJump();
    }
    
    
    void Update()
    {
#if UNITY_EDITOR
        if (Input.GetMouseButtonUp(0))
        {
            Debug.Log(IsHolding + "--- " + uIManager.gameState + " --- " + inAir);
        }
#endif
        
        if (uIManager.gameState == GameState.PLAYING)
        {
            if (inAir == false)
            {
                if (Input.GetMouseButtonDown(0))
                {
                    if (uIManager.IsButton())
                        return;

                    IsHolding = true;
                    _StartHoldTime = Time.time;
                    holdTime = 0f;
                }

                if (Input.GetMouseButton(0) && IsHolding)
                {
                    holdTime += Time.deltaTime;
                    float yCalculated = Mathf.Clamp(Mathf.Max(40, yPerTick * holdTime / Tick), MinForce, MaxForce);
                    energyHold.value = (yCalculated - MinForce) / (MaxForce - MinForce);
                }

                if (Input.GetMouseButtonUp(0) && IsHolding)
                {
                    IsHolding = false;
                    float yCalculated = Mathf.Clamp(Mathf.Max(40, yPerTick * holdTime / Tick), MinForce, MaxForce);
                    holdTime = 0f;
                    JumpEffect.transform.position = player.transform.position;
                    if (!inAir)
                    {
                        PlayerJump(yCalculated);
                    }
                }
            }

            
            complexSystem.DoUpdate(Time.deltaTime);
            
            // if (lastObstacle.transform.position.x < cam.transform.position.x + (2 * screenSize.x))
            //     CreateNewObstacle();
        }
        else
        {
            energyHold.value = 0;
            holdTime = 0;
            IsHolding = false;
        }
    }

    public ComplexSystem complexSystem = new ComplexSystem();
    //create new scene
    public void CreateScene()
    { 
        complexSystem.Init(this);
        complexSystem.CreateScene();
    }

    public void UpdateScore(int plusScore)
    {
        scoreManager.UpdateScore(plusScore);
        complexSystem.UpdateLevel(scoreManager.CurrentScore);
    }
    
    //restart game, reset score
    public void RestartGame()
    {
        if (uIManager.gameState == GameState.PAUSED)
            Time.timeScale = 1;

        cam.transform.position = new Vector3(0,0,-10);
        IsHolding = false;
        holdTime = 0f;
        
        scoreManager.ResetCurrentScore();
        ClearScene();
        CreateScene();
        uIManager.ShowGameplay();
        inAir = false;
        AudioManager.Instance.PlayMusic(AudioManager.Instance.gameMusic);
    }


    //clear all obstacles from scene
    public void ClearScene()
    {
        GameObject[] obstacles = GameObject.FindGameObjectsWithTag(DefineData.Tag.Obstacle);

        foreach (GameObject item in obstacles)
        {
            Destroy(item);
        }
    }

    public Obstacle findNearestObstacle()
    {
        GameObject[] obstacles = GameObject.FindGameObjectsWithTag(DefineData.Tag.Obstacle);

        GameObject min = null;
        // min = obstacles[0];
        for (int i = 0; i < obstacles.Length; i++)
        {
            if (obstacles[i].GetComponent<Obstacle>().index > player.before.GetComponent<Obstacle>().index)
            {
                if (min == null)
                    min = obstacles[i];

                if (Mathf.Abs(min.transform.position.x - player.transform.position.x)
                    > Mathf.Abs(obstacles[i].transform.position.x - player.transform.position.x))
                {
                    min = obstacles[i];
                }
            }
        }
        
        return min.GetComponent<Obstacle>();
    }

    public void PlayPerfect()
    {
        perfectAnimator.Play("Show");
        perfectAnimator.transform.GetComponent<Text>().material.color = GetRandomColor();
    }

    public Color GetRandomColor()
    {
        return obstacleColors[Random.Range(0, obstacleColors.Length)];
    }

    //show game over gui
    public void GameOver()
    {
        if (uIManager.gameState == GameState.PLAYING)
        {
            AudioManager.Instance.PlayEffects(AudioManager.Instance.gameOver);
            uIManager.ShowGameOver();
            scoreManager.UpdateScoreGameover();
        }
    }

    public void PlayAnim(string name, Color color){
        switch (name){
            case "jump":
                JumpEffect.transform.GetComponent<SpriteRenderer>().material.color = color;
                JumpEffect.gameObject.SetActive(true);
                JumpEffect.Play("jump");
                break;
            case "fall":
                FallEffect.transform.position = player.transform.position;
                FallEffect.transform.GetComponent<SpriteRenderer>().material.color = color;
                FallEffect.gameObject.SetActive(true);
                FallEffect.Play("fall");
                break;
            
        }
    }
}