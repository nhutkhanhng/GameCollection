using System;
using System.Collections;
using System.Collections.Generic;
using Cysharp.Threading.Tasks;
using Cysharp.Threading.Tasks.Linq;
using DG.Tweening;
using UnityEngine;


using DG;
using TMPro;

public class ObsFlicker : Obstacle
{
    [MinMaxCustomSlider] public ValueRange flickerTime;
    [SerializeField] protected TextMeshProUGUI timer;
    [SerializeField] protected GameObject graphic;
    protected float currentTime;
    
    
    public override void Init()
    {
        base.Init();
        isActive = true;
        
        timeToFlicker = Mathf.RoundToInt(flickerTime.GetRandomValue());
        currentTime = 0f;
        // _sequence = DOTween.Sequence();
        
        
        // _sequence.Append(DOVirtual.DelayedCall(flickerTime.GetRandomValue(),
        //     () =>
        //     {
        //         this.gameObject.SetActive(false);
        //     }));
        //
        // _sequence.Append(DOVirtual.DelayedCall(flickerTime.GetRandomValue(),
        //     () => { gameObject.SetActive(true); }));
        //
        // _sequence.SetLoops(-1);
    }

    protected float timeToFlicker;
    private void Update()
    {
        if (hit == false)
        {
            currentTime += Time.deltaTime;

            if (currentTime > timeToFlicker)
            {
                // timeToFlicker = flickerTime.GetRandomValue();
                isActive = !isActive;
                ToggleLogic(isActive);

                currentTime -= timeToFlicker;
            }
            
            if (currentTime > timeToFlicker - 1 && IsDissovling == false)
                DoDissovle(!this.isActive);


            this.timer.text = Mathf.FloorToInt((timeToFlicker - currentTime)).ToString();
        }
    }

    protected IEnumerator disslveRoutine;
    IEnumerator Dissovle(bool IsActive, float dissovleTime = 1f)
    {
        float currentTime = 0f;

        while (currentTime < dissovleTime)
        {
            currentTime += Time.deltaTime;
            if (IsActive == false)
                this.spriteRenderer.material.SetFloat("_Level", currentTime / dissovleTime);
            else
                this.spriteRenderer.material.SetFloat("_Level", 1 - currentTime / dissovleTime);
            yield return null;
        }

        IsDissovling = false;
    }
    protected bool isActive = true;

    protected void ToggleLogic(bool isActive)
    {
        // this.spriteRenderer.enabled = 
        this._collider2D.enabled = isActive;

     
    }

    protected bool IsDissovling = false;
    protected void DoDissovle(bool isActive)
    {
        IsDissovling = true;
        if (disslveRoutine != null)
        {
            StopCoroutine(disslveRoutine);
            disslveRoutine = Dissovle(isActive);
        }

        disslveRoutine = Dissovle(isActive);
        StartCoroutine(disslveRoutine);
    }
}
