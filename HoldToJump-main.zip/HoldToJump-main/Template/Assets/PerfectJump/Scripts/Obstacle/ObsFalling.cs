using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SocialPlatforms;

public class ObsFalling : Obstacle
{
    [Range(0f, .5f)] public float gravityScale = .3f;
    public override void BeHitted(Player player)
    {
        rigid.bodyType = RigidbodyType2D.Dynamic;
        rigid.gravityScale = gravityScale;
        rigid.constraints = RigidbodyConstraints2D.FreezePositionX | RigidbodyConstraints2D.FreezeRotation;
    }
}
