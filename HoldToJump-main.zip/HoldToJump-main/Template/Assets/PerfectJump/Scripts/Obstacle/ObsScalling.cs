using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObsScalling : Obstacle
{

    [MinMaxCustomSlider] public ValueRange scallingValue;
    public override void Init()
    {
        base.Init();
        this.transform.localScale = scallingValue.GetRandomValue() * Vector3.one;
    }
}
