﻿using System;
using UnityEngine;

public class Obstacle : MonoBehaviour
{
    public Rigidbody2D rigid;
    [SerializeField] public SpriteRenderer spriteRenderer;
    [SerializeField] protected BoxCollider2D _collider2D;

    public Vector2 Size => _collider2D.size;
    [HideInInspector] public int index;
    public bool hit;

    public virtual void Init()
    {
        
    }
    public void Awake()
    {
        if (!rigid)
            rigid = GetComponent<Rigidbody2D>();

        if (!_collider2D)
            _collider2D = GetComponent<BoxCollider2D>();

        if (!spriteRenderer)
            spriteRenderer = GetComponent<SpriteRenderer>();
    }

    void OnBecameInvisible()
    {
        DoInvisible();
    }

    protected virtual void DoInvisible()
    {
        if (GameManager.Instance.cam != null)
            if (transform.position.x < GameManager.Instance.cam.transform.position.x || transform.position.y < -10)
                Destroy(gameObject);
    }

    public virtual void BeHitted(Player player)
    {
        hit = true;
        // nothing.
        // rigid.bodyType = RigidbodyType2D.Dynamic;
        // rigid.gravityScale = 3f;
        // rigid.constraints = RigidbodyConstraints2D.FreezePositionX | RigidbodyConstraints2D.FreezeRotation;
    }
    
}
