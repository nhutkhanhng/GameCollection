using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using DG;
using DG.Tweening;

public class ObsShaking : Obstacle
{
    public enum XYZ
    {
        X,
        Y,
        // Z,
        Random,
    }
    [Range(0f, 1.5f)] public float range = .25f;
    [Range(.01f, 3f)] public float duration = .1f;

    protected Vector3 oldPosition;
    public PlatformCatcher catcher;
    public int Loops = -1;
    public XYZ axis = XYZ.Random; 
    protected void MoveX()
    {
        Sequence _sequence = DOTween.Sequence();

        _sequence.Append(
            this.transform.DOMoveX(-range, duration).SetEase(Ease.Linear).SetRelative(true));

        _sequence.Append(transform.DOMoveX(range, duration).SetEase(Ease.Linear).SetRelative(true));

        _sequence.SetLoops(Loops);
        _sequence.Play();
    }
    
    protected void MoveY()
    {
        Sequence _sequence = DOTween.Sequence();

        _sequence.Append(
            this.transform.DOMoveY(-range, duration).SetEase(Ease.Linear).SetRelative(true));

        _sequence.Append(transform.DOMoveY(range, duration).SetEase(Ease.Linear).SetRelative(true));

        _sequence.SetLoops(Loops);
        _sequence.Play();
    }
    public override void Init()
    {
        base.Init();

        var rd = UnityEngine.Random.Range(0, 2);
        switch (axis)
        {
            case XYZ.X: MoveX(); break;

            case XYZ.Y: MoveY(); break;

            default:
                if (UnityEngine.Random.Range(0, 2) > 0) MoveX(); else MoveY(); break;
        }

        if (catcher)
            catcher = GetComponent<PlatformCatcher>();
        
        oldPosition = transform.position;
    }
    
    private void FixedUpdate()
    {
        catcher.MoveCaughtObjects(transform.position - oldPosition);
        oldPosition = this.transform.position;
        
        
    }

    //     public override void BeHitted(Player player)
//     {
//         _player = player;
//         player.transform.parent = this.transform;
//         player.OnJump += OnJump;
//     }
//
//     private void OnDestroy()
//     {
//         if (_player)
//         {
//             _player.transform.parent = null;
//             _player = null;
//         }
//     }
//
//     private void OnJump(Player player)
//     {
//         _player = null;
//         player.transform.parent = null;
//         player.OnJump -= OnJump;
//     }
}
