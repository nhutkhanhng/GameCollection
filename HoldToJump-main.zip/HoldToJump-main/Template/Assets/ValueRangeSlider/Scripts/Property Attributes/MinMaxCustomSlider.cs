﻿using UnityEngine;
using System.Collections;

[System.Serializable]
public class MinMaxCustomSlider : PropertyAttribute
{
	public float PropertyWidth = 600;
}
