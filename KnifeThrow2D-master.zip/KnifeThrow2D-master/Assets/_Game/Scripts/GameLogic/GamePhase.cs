
public enum GamePhase
{
    NONE,
    MENU,
    GAMEPLAY,
}
