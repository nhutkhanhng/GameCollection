
public class GameDefine
{
    public const string KNIFE = "Knife";
}

public partial class MessageType
{
    public const string OnChangeGamePhase = "OnChangeGamePhase";
    public const string OnResetGame = "OnResetGame";
    public const string OnUpdateUI = "OnUpdateUI";
}
