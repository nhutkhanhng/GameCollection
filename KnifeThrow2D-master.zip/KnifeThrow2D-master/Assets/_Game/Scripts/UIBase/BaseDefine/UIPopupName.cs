public enum UIPopupName
{
    None = 0,
    PopupTest = 1,
    PopupEndGame = 2,
    PopupNextLevel = 3,
    PopupMainMenu = 4,
}
public enum UIPopupGame
{
    _Game
}
