using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FragmentOriginalPos : MonoBehaviour
{
    public Vector3 OriPos;
}
