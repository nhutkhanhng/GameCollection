﻿using System;

namespace Dispatcher
{
	public class DelayType
	{
        public const float Immdiate = 0f;
        
        public const float Next = -1f;
      
        public const float OneSecond = 1f;
	}
}
