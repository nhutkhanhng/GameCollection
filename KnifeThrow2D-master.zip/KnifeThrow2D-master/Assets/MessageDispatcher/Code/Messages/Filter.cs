﻿using System;

namespace Dispatcher
{
	public class Filter
	{
        public const int Name = 0;
        public const int Tag = 1;
	}
}
