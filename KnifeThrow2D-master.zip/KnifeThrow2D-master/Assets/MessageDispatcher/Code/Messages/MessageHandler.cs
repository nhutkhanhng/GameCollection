﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Dispatcher
{
    public delegate void MessageHandler(IMessage rMessage);
}
